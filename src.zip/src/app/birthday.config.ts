export interface BirthdayPhoto { src: string; alt: string; caption: string; }

/** Modifie ces valeurs et ajoute tes médias dans public/ pour personnaliser le site. */
export const BIRTHDAY = {
  name: 'Alexandra',
  dateLabel: '30 octobre 2026',
  // Le grand jour commence à minuit (UTC+00:00).
  celebrationAt: '2026-10-30T00:00:00+00:00',
  signature: 'ton jumeau',
  shortMessage: 'Aujourd’hui, le monde célèbre la belle personne que tu es. Que cette journée soit aussi lumineuse que ton sourire.',
  letter: 'En ce jour spécial, je te souhaite beaucoup de bonheur, une santé précieuse, de belles réussites et des raisons de sourire chaque jour. Que cette nouvelle année de ta vie t’apporte de belles surprises, de nouvelles opportunités et des moments inoubliables. Profite pleinement de cette journée qui est la tienne. Joyeux anniversaire !',
  secret: 'Le plus beau cadeau, c’est de te connaître. Garde cette petite étincelle avec toi, aujourd’hui et tous les jours.',
  heroImage: 'images/gallery/photo-01.jpeg',
  /** Active les liens de test ?preview=jour et ?preview=avant. Mets false avant de publier. */
  allowPreview: true,
  music: 'music/fete.mp3',
  /** Un souhait caché dans chaque ballon. */
  wishes: ['Santé et énergie', 'Des rires chaque jour', 'Des projets qui se réalisent', 'De belles rencontres', 'De la sérénité', 'Plein d’amour'],
  photos: [
    { src: 'images/gallery/photo-01.jpeg', alt: 'Un selfie en extérieur tous les deux', caption: 'Un moment à deux' },
    { src: 'images/gallery/photo-02.jpeg', alt: 'Un selfie souriant', caption: 'Un souvenir qui fait sourire' },
    { src: 'images/gallery/photo-03.jpeg', alt: 'Souvenir numéro trois', caption: 'Encore un beau moment' },
  ] satisfies BirthdayPhoto[],
} as const;
