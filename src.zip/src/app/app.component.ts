import { Component, DestroyRef, ElementRef, HostListener, OnInit, ViewChild, inject } from '@angular/core';
import { BIRTHDAY } from './birthday.config';
import { Fx, playMelody } from './fx';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  readonly b = BIRTHDAY;
  @ViewChild('fx', { static: true }) fxRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('partyAudio') partyAudio?: ElementRef<HTMLAudioElement>;

  stage: 'cake' | 'dark' | 'party' = 'cake';
  lit = false;      // bougies allumées
  ready = false;    // mélodie terminée : on peut souffler
  blown = false;    // bougies soufflées
  micOn = false;
  musicBlocked = false;
  musicStarted = false;
  lightboxIndex: number | null = null;
  popped: boolean[] = BIRTHDAY.wishes.map(() => false);

  private forced = BIRTHDAY.allowPreview ? new URLSearchParams(location.search).get('preview') : null;
  private remaining = this.left();
  private wasOpen = this.isOpen;
  private fx!: Fx;
  private ac?: AudioContext;
  private stream?: MediaStream;
  private raf = 0;
  private destroyRef = inject(DestroyRef);

  ngOnInit(): void {
    this.fx = new Fx(this.fxRef.nativeElement);
    const timer = window.setInterval(() => this.tick(), 1000);
    this.destroyRef.onDestroy(() => { clearInterval(timer); this.fx.destroy(); this.stopMic(); });
  }

  private left(): number { return Math.floor((new Date(BIRTHDAY.celebrationAt).getTime() - Date.now()) / 1000); }

  /** Le jour J (et après), l'expérience complète s'ouvre ; avant, on reste sur le compte à rebours. */
  get isOpen(): boolean {
    if (this.forced === 'jour') return true;
    if (this.forced === 'avant') return false;
    return this.remaining <= 0;
  }

  private tick(): void {
    this.remaining = this.left();
    if (!this.wasOpen && this.isOpen) { this.wasOpen = true; this.fx.show(); } // le compte à rebours atteint zéro en direct
  }

  get countdown() {
    const t = Math.max(0, this.remaining);
    return [
      { value: Math.floor(t / 86400), label: 'jours' },
      { value: Math.floor((t % 86400) / 3600), label: 'heures' },
      { value: Math.floor((t % 3600) / 60), label: 'minutes' },
      { value: t % 60, label: 'secondes' },
    ];
  }
  get days(): number { return Math.max(0, Math.ceil(this.remaining / 86400)); }
  /** La photo du teaser devient plus nette à mesure que le jour approche. */
  get teaserBlur(): number { return 6 + Math.max(0, Math.min(1, this.remaining / 86400 / 30)) * 20; }
  pad(n: number): string { return String(n).padStart(2, '0'); }

  // ---------- Gâteau ----------
  light(): void {
    if (this.lit) return;
    this.lit = true;
    let secs = 8;
    try { this.ac = new AudioContext(); secs = playMelody(this.ac); } catch { /* pas d'audio */ }
    setTimeout(() => { this.ready = true; this.startMic(); }, secs * 1000 + 300);
  }

  /** Détecte un souffle au micro (volume élevé soutenu). Sans micro, le bouton / le toucher suffisent. */
  private async startMic(): Promise<void> {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ac = this.ac ?? new AudioContext();
      const an = ac.createAnalyser();
      an.fftSize = 512;
      ac.createMediaStreamSource(this.stream).connect(an);
      const buf = new Uint8Array(an.fftSize);
      let hits = 0;
      this.micOn = true;
      const loop = () => {
        an.getByteTimeDomainData(buf);
        let s = 0;
        for (const v of buf) s += (v - 128) ** 2;
        hits = Math.sqrt(s / buf.length) / 128 > 0.2 ? hits + 1 : 0;
        if (hits > 10) { this.blow(); return; }
        this.raf = requestAnimationFrame(loop);
      };
      loop();
    } catch { this.micOn = false; }
  }

  private stopMic(): void {
    cancelAnimationFrame(this.raf);
    this.stream?.getTracks().forEach(t => t.stop());
    this.micOn = false;
  }

  cakeTap(): void { this.lit ? this.blow() : this.light(); }

  blow(): void {
    if (!this.lit || this.blown) return;
    this.blown = true;
    this.stopMic();
    setTimeout(() => this.stage = 'dark', 1200);
    setTimeout(() => {
      this.stage = 'party';
      scrollTo(0, 0);
      this.fx.show();
      this.fx.confetti(innerWidth / 2, innerHeight, 160);
      setTimeout(() => {
        const audio = this.partyAudio?.nativeElement;
        if (!audio) return;
        void audio.play().then(() => { this.musicBlocked = false; this.musicStarted = true; }).catch(() => this.musicBlocked = true);
      }, 0);
    }, 3000);
  }

  playPartyMusic(): void {
    const audio = this.partyAudio?.nativeElement;
    if (!audio) return;
    void audio.play().then(() => { this.musicBlocked = false; this.musicStarted = true; }).catch(() => this.musicBlocked = true);
  }

  more(): void { this.fx.confetti(innerWidth / 2, innerHeight, 120); }

  replay(): void {
    this.stage = 'cake'; this.lit = this.ready = this.blown = false;
    this.popped = this.popped.map(() => false);
    scrollTo(0, 0);
  }

  // ---------- Ballons & galerie ----------
  pop(i: number, e: MouseEvent): void { this.popped[i] = true; this.fx.confetti(e.clientX, e.clientY, 45); }
  openPhoto(i: number): void { this.lightboxIndex = i; }
  closePhoto(): void { this.lightboxIndex = null; }
  nextPhoto(d: number): void {
    if (this.lightboxIndex === null) return;
    const n = this.b.photos.length;
    this.lightboxIndex = (this.lightboxIndex + d + n) % n;
  }
  @HostListener('document:keydown', ['$event'])
  onKey(e: KeyboardEvent): void {
    if (this.lightboxIndex === null) return;
    if (e.key === 'Escape') this.closePhoto();
    if (e.key === 'ArrowRight') this.nextPhoto(1);
    if (e.key === 'ArrowLeft') this.nextPhoto(-1);
  }
  imageFailed(e: Event): void { (e.target as HTMLImageElement).hidden = true; }
}
